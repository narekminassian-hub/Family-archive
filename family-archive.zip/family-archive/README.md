# Minassian Family Archive

An interactive version of the six-generation chart. Every connection is taken
from the AutoCAD drawing — nothing was added, removed or re-parented. Only the
drawing method changed: positions are now computed, so generations sit on true
aligned rows and children always centre under their parents.

**172 people · 54 family units · generations 6 → 1**

---

## The files

| File | What it is |
|---|---|
| `index.html` | The whole application. No build step, no dependencies. |
| `data.js` | Every person and every link. This is the archive — guard this file. |
| `photos/` | Your scans go here. |

Open `index.html` by double-clicking it and it works offline, straight from
the folder. It only needs a web server when you want a public link.

---

## Getting a link

**GitHub Pages** — free, permanent, versioned, and you keep the data.

1. Create a GitHub account, then a new **public** repository called
   `family-archive`.
2. On the repo page choose **Add file → Upload files**, drag in `index.html`,
   `data.js` and the `photos` folder, and commit.
3. **Settings → Pages → Source: Deploy from a branch → main / (root) → Save.**
4. About a minute later your link is live at
   `https://<your-username>.github.io/family-archive/`

Every later change is another upload, and GitHub keeps every previous version —
so a bad edit is never lost.

**Netlify Drop** — faster, if you want a link in thirty seconds. Go to
`app.netlify.com/drop` and drag the whole folder onto the page. Good for
showing relatives; less good long-term, because there is no version history.

**Keeping it private.** Anything on GitHub Pages is public. If the family would
rather it were not, use a private repo and a paid Netlify or Cloudflare Pages
site with password protection, or simply email the folder as a zip — it runs
locally without a server.

---

## Adding dates, professions and photographs

### Through the browser (recommended)

1. Open the site, click a person, press **Edit details**.
2. Fill in what you know. Press **Save details**.
3. Repeat for as many people as you like — everything is held in the page.
4. Press **Download data.js** in the top bar and replace the old `data.js`.

Edits live only in that browser tab until you download. Do a session at a time
and download at the end of each one.

### Directly in `data.js`

Every person is one entry. All fields except `name` and `gen` are optional:

```js
"zina-minassian": {
  "id": "zina-minassian",
  "name": "Zina Minassian",
  "gen": 3,
  "sex": "f",
  "birth": "1941",
  "death": "",
  "places": "Yerevan · Tehran",
  "occupation": "Pharmacist",
  "photo": "photos/zina-minassian.jpg",
  "gallery": ["photos/zina-1968-wedding.jpg", "photos/zina-family.jpg"],
  "bio": "Two or three paragraphs. Line breaks are fine."
}
```

### Scanning the albums

- Scan at **600 dpi** for prints smaller than 10×15 cm, 300 dpi for larger.
  Keep the raw TIFF or maximum-quality JPEG somewhere safe — that is the
  preservation copy, and it should never be the file on the website.
- For the site, export JPEGs about **1600 px on the long edge**, quality 80.
  A 200-photo archive then stays around 40 MB, which loads fine on a phone in
  Yerevan and sits well inside GitHub's limits.
- Name files after the person's id, so they are self-sorting:
  `zina-minassian.jpg`, `zina-minassian-1968-wedding.jpg`.
- Photograph the **back** of any print that has writing on it. Names and dates
  in a relative's handwriting are the most valuable thing in the album, and
  they are the first thing lost.

---

## Adding a person

Add them to `persons`, then attach them in `families`. A family is one couple
plus their children:

```js
{ "id": "f-zina-arsen",
  "partners": ["zina-minassian", "arsen-ghazarian"],
  "children": ["arsine-ghazarian", "edwin-ghazarian"],
  "kind": "married" }
```

Rules the layout relies on:

- Every person appears as a child in **at most one** family.
- A single parent is written `"partners": ["someone", null]`.
- `gen` decides the row. 6 is the earliest recorded generation, 1 the youngest.
  Nala is generation 0.

---

## Reading the chart

- **Dashed plate** — the person is on your chart but unnamed or unidentified.
  Sixteen people are currently in this state; they are gaps in the record, not
  in the drawing.
- **Dashed horizontal line** — a marriage between two branches that sit far
  apart on the sheet. There are six, and they are the same long horizontals you
  drew in AutoCAD: Yengibar ↔ Goharik, Lala ↔ Onik, Razmik ↔ Lorik,
  Areg ↔ Nana, Stella ↔ Vazgen, Armen ↔ Nelly.
- **Red bar** — you.
- **Lineage** — open anyone and press it; everyone outside their bloodline
  fades, which is the only practical way to read 172 people at once.
- `/` jumps to search. `Esc` closes. Cards are keyboard-reachable.

---

## Worth verifying against the originals

These were the hardest junctions to read from the scan, and are the places
where I would check the drawing again before treating the data as final:

1. **Frieda, Zina, Ida and Razmik** all attach to Gurgen Minassian +
   Tigranuhi Antonian. On the drawing this is one long sibling bar and the
   riser is partly hidden behind Eghizabeth's caption.
2. **Armenuhi Minassian** and **Eghizabeth Minassian (Yekhso)** are recorded
   with no descendants. If they had children, they are missing.
3. **Andranik Ghazarian** is drawn as Arsen's brother, but their parents are
   not on the chart, so the pair floats.
4. **Sako, Avo, Lorik and Artem Antonian** appear only as text under Armin
   Antonian, with no mother named.
5. **Samvel Shushanian + Anik Yeritsyan** sit in plain boxes with no
   generation label; I placed them at generation 4 because their sons married
   into generation 3.
6. Two men named **Vardan Hovsepian** and two named **Gurgen Sargsian** exist
   one generation apart. They are separate records; check they are the right
   way round.
7. **Solak's wife, Komitas's wife** and **Shara's wife** are unnamed, and one
   of Babken Minassian and Arax Azizian's two children has no caption.

---

## If you want to go further

The data model here is deliberately close to **GEDCOM**, the genealogy
interchange format. When the records are fuller, exporting to GEDCOM would let
you open the same archive in Gramps or webtrees, attach sources and scans per
fact, and hand the whole thing to the next person who takes it over — which
matters more than any particular website surviving.
