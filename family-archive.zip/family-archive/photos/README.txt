Put your scans here.

Name them after the person's id in data.js, for example:
  zina-minassian.jpg              -> the portrait on their card and page
  zina-minassian-1968-wedding.jpg -> extra photos for their gallery

Then reference them in data.js:
  "photo":   "photos/zina-minassian.jpg",
  "gallery": ["photos/zina-minassian-1968-wedding.jpg"]

Or add them through Edit details in the browser.
